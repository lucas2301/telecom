# Messaging et REST Service

Dans cette version de l'application, on veut pouvoir contrôler les modifications
de la base d'information grâce à un système de messagerie (RabbitMQ) en utilisant
des workers qui seront en charge de se partager les envois de messages envoyés par des clients
en concurrence.

Ce TP est inspiré du tutorial Workers de RabbitMQ
https://www.rabbitmq.com/tutorials/tutorial-two-spring-amqp.html

Le nouveau module rabbit contient une application Spring incluant un receveur et un émetteur
La classe message config permet l'instantiation des beans pour deux profils (sender et receiver)
Deux workers sont démarrés pour consommer les messages de la queue.

Une façon de contrôler l'arrivée des requêtes consiste à les recevoir dans une queue de message.
Le receveur des messages pourra envoyer aux API. On fera ça pour la création de clubs.

## L'environnement

* Le module **rabbit** permet d'envoyer et de recevoir les messages. C'est là qu'il faudra faire les modifications pour faire en sorte que le receveur des messages appelle ensuite l'API de création des clubs.
* docker-compose.yml permet le démarrage d'une image docker et d'une image rabbitmq.
* le fichier de configuration de Maven (pom.xml) a été modifié pour ajouter les librairies Rabbitmq

## A Faire

* Le client ClubSender doit poster des messages qui seront reçus par des workers ClubReceiver pour créer des clubs
* La création des clubs se fait par appel des API de l'interface REST

* Un nouveau service REST a été ajouté qui permet d'enregistrer les opérations de création de club dans des ClubRecord qui sont stockés ave une base REDIS
* Proposez et implantez une solution permettant d'enregistrer ces opérations de façon sure en utilisant une approche de type publish/subscribe
  * Faites un schéma de l'architecture de l'application
  * Implantez ce qu'il faut pour que ça fonctionne
  * Comment faire pour tester que cela fonctionne. Qu'est ce qui pose problème ? Comment pourrait-on tester que ça fonctionne correctement ?
