package eu.telecomnancy.messagetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessagetestApplicationTests {

    @Test
    void contextLoads() {
    }

}
