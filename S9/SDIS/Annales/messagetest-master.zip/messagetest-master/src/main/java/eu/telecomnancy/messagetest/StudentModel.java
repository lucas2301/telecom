package eu.telecomnancy.messagetest;

import lombok.AllArgsConstructor;
import lombok.Value;

import java.util.Set;
import java.util.stream.Collectors;

@Value
@AllArgsConstructor
public class StudentModel {

         Long id;
         String name;
         Set<ClubModel> preside;

        public StudentModel(Student student) {
                id=student.getId();
                name=student.getName();
                if (student.getPreside()!=null) {
                        preside = student.getPreside().stream().map(ClubModel::new).collect(Collectors.toSet());
                } else preside=null;
        }

}
