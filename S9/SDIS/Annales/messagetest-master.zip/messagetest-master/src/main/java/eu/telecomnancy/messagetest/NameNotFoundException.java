package eu.telecomnancy.messagetest;

public class NameNotFoundException extends RuntimeException {
    public NameNotFoundException(String name) {
        super("Could not find item named " + name);
    }
}
