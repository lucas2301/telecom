CREATE DATABASE IF NOT EXISTS springbootdb;
USE springbootdb;