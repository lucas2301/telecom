# Docker et Docker-compose

Docker est une plateforme permettant de lancer des applications
dans des conteneurs afin qu'elles soient exécutées chacune de leur côté.  
Les conteneurs permettent de contourner la phase d'installation et de
configuration qui peut être différente suivant les machines
et poser problème.

## Docker, conteneurs et images

Docker permet de manipuler facilement des __images__ évoluant dans des
__conteneurs__. La conteneurisation (le fait d'empaqueter une application
dans un conteneur) permet de lancer cette application dans un environnement
contrôlé, configurable, et distinct de la machine hôte. Cela se rapproche
de l'utilisation d'une machine virtuelle mais en est une alternative
beaucoup plus légère. L'__image__ d'un conteneur est un fichier statique non
modifiable qui inclut les bibliothèques et les outils systèmes nécessaires
à l'exécution d'un programme.

## Utilisation

Docker permet donc la manipulation d'images et la conteneurisation
d'application. On peut par exemple lancer un bash ubuntu dans un conteneur
très facilement sans avoir à installer quoi que ce soit. L'instance sera
lancée et utilisable indépendamment de la machine hôte. Elle bénéficie
de sa propre configuration réseau, et se voit attribuer son propre
espace mémoire.

Pour débuter avec Docker : https://www.youtube.com/watch?v=SXB6KJ4u5vg&list=PL8SZiccjllt1jz9DsD4MPYbbiGOR_FYHu

### Cas de notre application

Pour l'instant notre application est hébergée sur la machine hôte
lorsqu'elle est lancée depuis IntelliJ. Pour y accéder depuis le browser,
on se connecte à l'adresse http://localhost:8080, donc au port 8080
de la machine.  
Ce que l'on veut faire désormais faire, c'est tester la capacité de l'application
à gérer la charge. Pour cela, on va utiliser la plateforme Artillery.io :
https://artillery.io/  
Cette plateforme permet d'automatiser la création de connection et
d'utilisation de l'application à travers l'écriture de scénarios.
Le script se trouve dans le dossier scripts à la racine du projet
(c'est le fichier loadtest.yml).  
Afin de se passer de l'installation d'Artillery sur la machine, on va utiliser
une image Docker. Et pour faciliter la communication entre l'application
et l'image artillery, on va aussi dockerizer l'application.

Pour cela on va utiliser un fichier _Dockerfile_ qui va contenir des instructions
pour la création d'une image.  
https://spring.io/guides/gs/spring-boot-docker/ pour en voir un peu plus,
sinon le fichier Dockerfile est commenté.

## Docker-compose

Maintenant que l'on peut créer une image de l'application dans un conteneur,
il ne reste qu'à lancer les deux en même temps. Pour cela nous allons
utiliser _Docker-compose_ qui permet de gérer plusieurs images simultanément,
à l'aide d'un fichier de configuration _docker-compose.yml_.  
Le fichier Docker-compose va s'occuper de créer un réseau permettant aux
images de communiquer, construire l'image de l'application à l'aide du Dockerfile,
puis une fois démarrée lancer une image d'_artillery_ dans laquelle on va monter
le script que l'on veut lancer et exécuter ce script.  
Une fois ce fichier en place il suffit de l'exécuter avec la commande
`"docker-compose up --build"` dans la racine du projet et tout se met en place tout seul.

La source d'inspiration : https://www.jetbrains.com/help/idea/run-and-debug-a-spring-boot-application-using-docker-compose.html
 
