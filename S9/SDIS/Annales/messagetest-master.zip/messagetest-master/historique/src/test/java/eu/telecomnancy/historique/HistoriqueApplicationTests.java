package eu.telecomnancy.historique;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoriqueApplicationTests {

    @Test
    void contextLoads() {
    }

}
