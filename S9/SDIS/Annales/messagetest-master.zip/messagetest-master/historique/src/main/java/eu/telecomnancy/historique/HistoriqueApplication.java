package eu.telecomnancy.historique;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HistoriqueApplication {

    public static void main(String[] args) {
        SpringApplication.run(HistoriqueApplication.class, args);
    }

}
