package eu.telecomnancy.rabbit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitApplicationTests {

    @Test
    void contextLoads() {
    }

}
