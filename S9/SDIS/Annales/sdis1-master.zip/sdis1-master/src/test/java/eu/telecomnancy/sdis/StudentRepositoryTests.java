package eu.telecomnancy.sdis;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import static org.assertj.core.api.Assertions.*;


@SpringBootTest
class StudentRepositoryTests {
    @Autowired
    private DataSource dataSource;
    @Autowired private JdbcTemplate jdbcTemplate;
    @Autowired private EntityManager entityManager;
    @Autowired private StudentRepository studentRepository;
    @Autowired private ClubRepository clubRepository;
    @Test
    void contextLoads() {
    }

    @Test
    public void injectedComponentsAreNotNull(){
        assertThat(dataSource).isNotNull();
        assertThat(jdbcTemplate).isNotNull();
        assertThat(entityManager).isNotNull();
        assertThat(studentRepository).isNotNull();
    }

    @Test
    public void whenSaved_thenFindsByName() {
        studentRepository.save(new Student(
                "Canard"));
        assertThat(studentRepository.findByName("Canard")).isNotNull();
    }

    @Test
    public void whenSaved_thenFindsById() {
        Student s=new Student(
                "Bobard");
        studentRepository.save(s);
        assertThat(studentRepository.findById(s.getId())).isNotNull();
    }

    @Test void assignStudentToClub() {
        Student s=new Student("Louis");
        Student t=new Student("Irène");
        Club c=new Club("Pinard");

        clubRepository.save(c);
        studentRepository.save(s);
        s.addClub(c);
        studentRepository.saveAndFlush(s); // To make sure the object and the relation are saved
        assertThat(clubRepository.findByName("Pinard")).isNotNull();
        assertThat(studentRepository.findByName("Louis").getClubs().size()).isEqualTo(1);
        assertThat(studentRepository.findByName("Louis").getClubs().get(0).getName()).isEqualTo("Pinard");
    }

    @Test void assignSeveralStudentsToClub() {
        Student s=new Student("Hélène");
        Student t=new Student("Raymond");
        Club c=new Club("Dancing");

        clubRepository.save(c);
        studentRepository.save(s);
        studentRepository.save(t);

        s.addClub(c);
        t.addClub(c);
        studentRepository.saveAndFlush(s); // To make sure the object and the relation are saved

        // voir https://www.baeldung.com/assertj-exception-assertion
        assertThatExceptionOfType(DataIntegrityViolationException.class).isThrownBy(()->studentRepository.saveAndFlush(t));

        assertThat(clubRepository.findByName("Dancing")).isNotNull();
        assertThat(studentRepository.findByName("Hélène").getClubs().size()).isEqualTo(1);
        assertThat(studentRepository.findByName("Hélène").getClubs().get(0).getName()).isEqualTo("Dancing");
    }

}

