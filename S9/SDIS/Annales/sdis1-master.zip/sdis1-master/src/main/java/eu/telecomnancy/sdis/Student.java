package eu.telecomnancy.sdis;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
public class Student {

    private @Id @GeneratedValue Long id;
    @Column(unique = true)
    private String name;
    @OneToMany(fetch = FetchType.EAGER)
    private List<Club> clubs;

    /* Constructors */

    Student() {

    }

    public Student(String name) {
        this.name = name;
    }

    /* Getters */

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public List<Club> getClubs() {
        return this.clubs;
    }

    /* Setters */

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    /* Adder */

    public void addClub (Club club) {
        if (this.clubs == null) {
            this.clubs = new ArrayList<Club>();
        }
        this.clubs.add(club);
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + this.id + ", name='" + this.name + '\'';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student student = (Student) obj;
        return Objects.equals(id , student.getId()) &&
                Objects.equals(name , student.getName()) &&
                Objects.equals(clubs, student.getClubs());
    }
}
