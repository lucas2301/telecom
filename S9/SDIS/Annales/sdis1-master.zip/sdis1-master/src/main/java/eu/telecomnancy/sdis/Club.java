package eu.telecomnancy.sdis;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Objects;

@Entity
public class Club {

    private @Id @GeneratedValue Long id;

    /* Constraints on the column */
    @Column(unique = true)
    private String name;

    /* Constructors */

    public Club(String name) {
        this.name = name;
    }

    public Club() {

    }

    /* Getters */

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return name;
    }

    /* Setters */

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    /* Adder */

    @Override
    public String toString() {
        return "Club{" + "id=" + this.id + ", name='" + this.name +'\'' + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || obj.getClass() != getClass()) return false;
        Club club = (Club) obj;
        return Objects.equals(id, club.id) &&
                Objects.equals(name, club.name);
    }
}
