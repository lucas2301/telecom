## TP Persistence

* Clonez le projet et exécutez le dans IntellIJ (run SdisApplication)
Vous verrez une trace d'exécution compliquée, y compris avec des erreurs dans la console.
  Ces erreurs sont normales en particulier à la première exécution
  
* Exécutez les Tests (dans le menu contextuel du projet, faire Run all tests)

Vous pouvez consulter le code pour comprendre ce qui se passe.

* Modifiez la classe pour qu'un ou une étudiante puisse appartenir à plusieurs clubs (relation n-m)

* Ajoutez une entité Salle. Un Club sera affecté à une salle. Plusieurs Clubs peuvent partager une salle.

* Ajoutez une relation entre étudiant et club permettant d'indiquer qu'un ou une étudiante peut être
  la présidente d'un club. Un club ne peut avoir qu'une ou un président.
  
Pour chacune des questions ajoutez des tests permettant de vérifier le fonctionnement de votre code sous la forme de
requêtes permettant de vérifier les ajouts et les retraits.
