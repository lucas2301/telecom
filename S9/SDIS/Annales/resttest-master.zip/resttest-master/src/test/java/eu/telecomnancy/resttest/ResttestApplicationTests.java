package eu.telecomnancy.resttest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResttestApplicationTests {

    @Test
    void contextLoads() {
    }

}
